

const Diagnostics = require('Diagnostics');
const Scene = require('Scene');
const CameraInfo = require('CameraInfo');
const Patches = require('Patches');



//native ui
const NativeUI = require('NativeUI');
const Textures = require('Textures');
const Reactive = require('Reactive');



var texture1 = null
var texture2 = null
var texture3 = null
var texture4 = null
var texture5 = null


var picker = NativeUI.picker;
const index = 0;

let pickerSelected = 0;


Promise.all([
    Textures.findFirst('MoodIcon'),
    Textures.findFirst('MeIcon'),
    Textures.findFirst('YouIcon'),
    Textures.findFirst('UsIcon'),
    Textures.findFirst('VibesIcon')
    
]).then((loadedItems)=> {
    texture1 = loadedItems[0];
    texture2 = loadedItems[1];
    texture3 = loadedItems[2];
    texture4 = loadedItems[3];
    texture5 = loadedItems[4];

    



    const configuration = {

        selectedIndex: index,

        items: [
            {image_texture: texture1},
            {image_texture: texture2},
            {image_texture: texture3},
            {image_texture: texture4},
            {image_texture: texture5}

        ]
    };


    picker.configure(configuration);
    picker.visible = true;

    picker.selectedIndex.monitor().subscribe(function(val) {
        Patches.inputs.setScalar('selectedIndex', val.newValue);
        pickerSelected = val.newValue;
    });

    
})


/*
//slider

var sliderVal = 2;
var slider = NativeUI.slider;

slider.value.monitor({fireOnInitialValue: false}).subscribe(function(val){
    sliderVal = val.newValue;
    Patches.inputs.setScalar('sliderIndex', val.newValue);
});

slider.value = sliderVal;
slider.visible = true;
*/
